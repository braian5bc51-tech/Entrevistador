import React, { useState, useRef, useEffect } from 'react';

interface Props {
  onDone: (transcript: string) => void;
}

type RecordingState = 'idle' | 'recording' | 'stopped';

export default function Recorder({ onDone }: Props) {
  const [state, setState] = useState<RecordingState>('idle');
  const [seconds, setSeconds] = useState(0);
  const [liveText, setLiveText] = useState('');
  const [supported, setSupported] = useState(true);

  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const accumulatedRef = useRef('');
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    const SR = (window as unknown as { SpeechRecognition?: typeof SpeechRecognition; webkitSpeechRecognition?: typeof SpeechRecognition }).SpeechRecognition
      || (window as unknown as { SpeechRecognition?: typeof SpeechRecognition; webkitSpeechRecognition?: typeof SpeechRecognition }).webkitSpeechRecognition;
    if (!SR) setSupported(false);
  }, []);

  function formatTime(s: number) {
    const m = Math.floor(s / 60);
    const ss = s % 60;
    return `${String(m).padStart(2, '0')}:${String(ss).padStart(2, '0')}`;
  }

  function startRecording() {
    const SR = (window as unknown as { SpeechRecognition?: typeof SpeechRecognition; webkitSpeechRecognition?: typeof SpeechRecognition }).SpeechRecognition
      || (window as unknown as { SpeechRecognition?: typeof SpeechRecognition; webkitSpeechRecognition?: typeof SpeechRecognition }).webkitSpeechRecognition;
    if (!SR) return;

    accumulatedRef.current = '';
    setLiveText('');
    setSeconds(0);
    setState('recording');

    const recognition = new SR();
    recognition.lang = 'es-AR';
    recognition.continuous = true;
    recognition.interimResults = true;
    recognitionRef.current = recognition;

    let interimBuffer = '';

    recognition.onresult = (event) => {
      let interim = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        if (result.isFinal) {
          accumulatedRef.current += result[0].transcript + ' ';
        } else {
          interim += result[0].transcript;
        }
      }
      interimBuffer = interim;
      setLiveText(accumulatedRef.current + interimBuffer);
    };

    recognition.onend = () => {
      // Si sigue en recording (corte automático), reinicar
      if (state === 'recording' || recognitionRef.current === recognition) {
        try { recognition.start(); } catch { /* ignorar */ }
      }
    };

    recognition.onerror = (e) => {
      if (e.error !== 'no-speech' && e.error !== 'aborted') {
        console.warn('Speech recognition error:', e.error);
      }
    };

    recognition.start();

    timerRef.current = setInterval(() => {
      setSeconds((s) => s + 1);
    }, 1000);
  }

  function stopRecording() {
    setState('stopped');

    if (timerRef.current) clearInterval(timerRef.current);

    if (recognitionRef.current) {
      recognitionRef.current.onend = null; // evitar reinicio
      recognitionRef.current.stop();
      recognitionRef.current = null;
    }
  }

  function handleContinue() {
    const text = accumulatedRef.current.trim();
    if (text) {
      onDone(text);
    }
  }

  function handleRestart() {
    accumulatedRef.current = '';
    setLiveText('');
    setSeconds(0);
    setState('idle');
  }

  if (!supported) {
    return (
      <div className="screen">
        <div className="screen-icon">⚠️</div>
        <h2>Reconocimiento de voz no disponible</h2>
        <p className="screen-desc">
          Tu navegador no soporta Web Speech API. Usá Chrome en Android o
          pegá la transcripción manualmente.
        </p>
        <button className="btn btn-primary" onClick={() => onDone('')}>
          Ingresar transcripción manualmente
        </button>
      </div>
    );
  }

  return (
    <div className="screen recorder-screen">
      {state === 'idle' && (
        <>
          <div className="screen-icon pulse-ready">🎙️</div>
          <h2>Grabar entrevista</h2>
          <p className="screen-desc">
            Presioná el botón para comenzar. Hablá claramente en español y
            el texto aparecerá en pantalla.
          </p>
          <button className="btn btn-record" onClick={startRecording}>
            ● Iniciar grabación
          </button>
        </>
      )}

      {state === 'recording' && (
        <>
          <div className="recording-indicator">
            <div className="rec-dot" />
            <span className="rec-label">GRABANDO</span>
            <span className="rec-timer">{formatTime(seconds)}</span>
          </div>

          <div className="live-transcript">
            {liveText || (
              <span className="placeholder">Empezá a hablar...</span>
            )}
          </div>

          <button className="btn btn-stop" onClick={stopRecording}>
            ■ Detener grabación
          </button>
        </>
      )}

      {state === 'stopped' && (
        <>
          <div className="screen-icon">✅</div>
          <h2>Grabación finalizada</h2>
          <p className="screen-desc">
            {formatTime(seconds)} grabados
          </p>

          <div className="live-transcript preview">
            {accumulatedRef.current.trim() || (
              <span className="placeholder">No se detectó texto. Intentá de nuevo.</span>
            )}
          </div>

          <div className="btn-group">
            <button className="btn btn-secondary" onClick={handleRestart}>
              ↩ Grabar de nuevo
            </button>
            <button
              className="btn btn-primary"
              onClick={handleContinue}
              disabled={!accumulatedRef.current.trim()}
            >
              Revisar transcripción →
            </button>
          </div>
        </>
      )}
    </div>
  );
}
