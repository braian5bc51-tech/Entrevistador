import { PatientData } from '../types';

const PROMPT = `Sos el asistente de carga de datos para el registro de pacientes de pruebas de esfuerzo (CPET) de VO2MAX (Fundación Luquez). Recibís una transcripción de entrevista clínica.

Extraé los datos de CADA paciente mencionado y devolvé SOLO un JSON válido — sin texto adicional, sin bloques de código markdown — con exactamente este formato:

[
  {
    "nombre": "Apellido, Nombre",
    "dni": "XX.XXX.XXX",
    "edad": 00,
    "medicoDerivante": "Dr./Dra. Nombre Apellido",
    "motivoConsulta": "texto completo",
    "antecedentesMedicos": "texto completo",
    "medicacionActual": "texto completo",
    "actividadFisica": "texto completo",
    "sintomasReportados": "texto completo",
    "observacionesTecnico": "texto completo",
    "estado": "Entrevista cargada",
    "notas": "texto o vacío"
  }
]

REGLAS ESTRICTAS:
— Nunca uses abreviaturas médicas. Siempre el término completo: "hipertensión arterial" (nunca HTA), "infarto agudo de miocardio" (nunca IAM), "frecuencia cardíaca" (nunca FC), "electrocardiograma" (nunca ECG), "presión arterial" (nunca PA).
— Si un dato no aparece en la transcripción, dejá el campo como "" (string vacío).
— Si falta el nombre, escribí "(sin nombre registrado)".
— Si un dato es poco claro (audio confuso o número incompleto), escribilo tal como se entiende y agregá "(confirmar con el paciente)" al final.
— Estado: "Prueba realizada" si la transcripción describe lo que ocurrió durante o después del estudio. "Entrevista cargada" si es solo pre-prueba.
— Español correcto, con tildes, sin abreviaturas.
— Devolvé SOLO el array JSON. Sin texto antes ni después.`;

export async function extractPatientData(
  transcript: string,
  apiKey: string,
  date: string
): Promise<PatientData[]> {
  if (!apiKey.trim()) {
    throw new Error('Falta la clave de API de Claude. Configurala en Ajustes.');
  }

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey.trim(),
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 4000,
      system: PROMPT,
      messages: [
        {
          role: 'user',
          content: `Fecha del estudio: ${date}\n\nTranscripción:\n\n${transcript}`,
        },
      ],
    }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    const msg = (err as any)?.error?.message || `Error ${response.status}`;
    throw new Error(`Error de API: ${msg}`);
  }

  const data = await response.json();
  const text = data.content?.[0]?.text ?? '';

  // Limpiar posible markdown de código
  const clean = text.replace(/```json|```/g, '').trim();

  try {
    const parsed = JSON.parse(clean);
    if (!Array.isArray(parsed)) throw new Error('El modelo no devolvió un array');
    return parsed as PatientData[];
  } catch {
    throw new Error('El modelo devolvió un formato inesperado. Revisá la transcripción e intentá de nuevo.');
  }
}
