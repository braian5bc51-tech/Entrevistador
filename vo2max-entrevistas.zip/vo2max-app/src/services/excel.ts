import * as XLSX from 'xlsx';
import { PatientData } from '../types';

const HEADERS = [
  'Fecha del estudio',
  'Nombre del paciente',
  'DNI',
  'Edad',
  'Médico derivante',
  'Motivo de consulta',
  'Antecedentes médicos',
  'Medicación actual',
  'Actividad física / Estilo de vida',
  'Síntomas reportados',
  'Observaciones del técnico',
  'Estado',
  'Notas',
];

const COL_WIDTHS = [14, 24, 16, 8, 22, 26, 36, 28, 32, 34, 34, 18, 22];

// Colores
const DARK_BLUE = '1A3A5C';
const YELLOW = 'FFF2CC';
const GREEN = 'D9EAD3';
const AMBER = 'FCE5CD';
const WHITE = 'FFFFFF';

function cellStyle(overrides: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    font: { name: 'Arial', sz: 10 },
    alignment: { wrapText: true, vertical: 'top' },
    border: {
      top: { style: 'thin', color: { rgb: 'B7B7B7' } },
      bottom: { style: 'thin', color: { rgb: 'B7B7B7' } },
      left: { style: 'thin', color: { rgb: 'B7B7B7' } },
      right: { style: 'thin', color: { rgb: 'B7B7B7' } },
    },
    ...overrides,
  };
}

export function generateExcel(patients: PatientData[], date: string): void {
  const wb = XLSX.utils.book_new();

  // ─── Hoja 1: Registro ───────────────────────────────────────────
  const ws: XLSX.WorkSheet = {};

  const totalCols = HEADERS.length;
  const lastCol = XLSX.utils.encode_col(totalCols - 1);

  // Fila 1: Título
  ws['A1'] = {
    v: 'REGISTRO DE PACIENTES - PRUEBAS DE ESFUERZO (CPET)',
    s: {
      font: { name: 'Arial', sz: 14, bold: true, color: { rgb: WHITE } },
      fill: { fgColor: { rgb: DARK_BLUE } },
      alignment: { horizontal: 'center', vertical: 'center' },
    },
  };
  ws['!merges'] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: totalCols - 1 } }];

  // Fila 2: Subtítulo
  ws['A2'] = {
    v: 'VO2MAX - Evaluación Deportológica y Cardiopulmonar | Fundación Luquez',
    s: {
      font: { name: 'Arial', sz: 10, italic: true, color: { rgb: DARK_BLUE } },
      alignment: { horizontal: 'center' },
    },
  };
  ws['!merges'].push({ s: { r: 1, c: 0 }, e: { r: 1, c: totalCols - 1 } });

  // Fila 3: Conteo
  ws['A3'] = {
    v: `Total de pacientes registrados: ${patients.length}`,
    s: {
      font: { name: 'Arial', sz: 10, bold: true, color: { rgb: DARK_BLUE } },
      alignment: { horizontal: 'center' },
    },
  };
  ws['!merges'].push({ s: { r: 2, c: 0 }, e: { r: 2, c: totalCols - 1 } });

  // Fila 5 (índice 4): Encabezados
  HEADERS.forEach((h, i) => {
    const addr = XLSX.utils.encode_cell({ r: 4, c: i });
    ws[addr] = {
      v: h,
      s: {
        font: { name: 'Arial', sz: 10, bold: true },
        fill: { fgColor: { rgb: 'D9E1F2' } },
        alignment: { horizontal: 'center', vertical: 'center', wrapText: true },
        border: {
          top: { style: 'thin', color: { rgb: 'B7B7B7' } },
          bottom: { style: 'medium', color: { rgb: DARK_BLUE } },
          left: { style: 'thin', color: { rgb: 'B7B7B7' } },
          right: { style: 'thin', color: { rgb: 'B7B7B7' } },
        },
      },
    };
  });

  // Filas de datos (a partir de la fila 6, índice 5)
  patients.forEach((p, rowIdx) => {
    const r = 5 + rowIdx;
    const rowData = [
      date,
      p.nombre,
      p.dni,
      p.edad,
      p.medicoDerivante,
      p.motivoConsulta,
      p.antecedentesMedicos,
      p.medicacionActual,
      p.actividadFisica,
      p.sintomasReportados,
      p.observacionesTecnico,
      p.estado,
      p.notas,
    ];

    rowData.forEach((val, c) => {
      const addr = XLSX.utils.encode_cell({ r, c });
      const isEmpty = val === '' || val === null || val === undefined;
      const isEstado = c === 11;

      let fill = {};
      if (isEmpty) {
        fill = { fgColor: { rgb: YELLOW } };
      } else if (isEstado) {
        fill = {
          fgColor: {
            rgb: val === 'Prueba realizada' ? GREEN : AMBER,
          },
        };
      }

      ws[addr] = {
        v: val ?? '',
        s: {
          ...cellStyle(Object.keys(fill).length ? { fill } : {}),
          alignment: {
            wrapText: true,
            vertical: 'top',
            horizontal: c === 2 || c === 3 || c === 11 ? 'center' : 'left',
          },
        },
      };
    });
  });

  // Rango de la hoja
  const lastDataRow = 5 + patients.length - 1;
  ws['!ref'] = `A1:${lastCol}${lastDataRow + 1}`;

  // Anchos de columna
  ws['!cols'] = COL_WIDTHS.map((w) => ({ wch: w }));

  // Altos de fila
  ws['!rows'] = [
    { hpt: 26 }, // título
    { hpt: 16 }, // subtítulo
    { hpt: 16 }, // conteo
    { hpt: 6 },  // espaciador
    { hpt: 42 }, // encabezados
    ...patients.map(() => ({ hpt: 90 })),
  ];

  XLSX.utils.book_append_sheet(wb, ws, 'Registro Pacientes');

  // ─── Hoja 2: Instrucciones ──────────────────────────────────────
  const ws2: XLSX.WorkSheet = {};
  ws2['A1'] = { v: 'Cómo usar este registro', s: { font: { name: 'Arial', sz: 14, bold: true, color: { rgb: DARK_BLUE } } } };
  const instrucciones = [
    'Cada fila es un paciente. Los datos de la entrevista pre-prueba van en las primeras columnas.',
    'Columna Estado: "Entrevista cargada" → anamnesis cargada. "Prueba realizada" → estudio hecho. "Informe enviado a cardióloga" → informe enviado.',
    'Las celdas en amarillo indican datos que faltan completar.',
    'Este archivo fue generado con la app VO2MAX Entrevistas.',
  ];
  instrucciones.forEach((line, i) => {
    ws2[`A${i + 3}`] = { v: `•  ${line}`, s: { font: { name: 'Arial', sz: 11 }, alignment: { wrapText: true } } };
  });
  ws2['!ref'] = `A1:A${instrucciones.length + 3}`;
  ws2['!cols'] = [{ wch: 100 }];
  XLSX.utils.book_append_sheet(wb, ws2, 'Instrucciones');

  // ─── Descargar ─────────────────────────────────────────────────
  const fileName = `${date.replace(/\//g, '-')}.xlsx`;
  XLSX.writeFile(wb, fileName);
}
